THIS IS NOT THE OFICIAL RC7! IT'S A REMAKE.

HOW TO USE IT: Auto-Attach, A for Auton-Run Scripts, button W enables/disables WordWrap, Google Drive button invites you to my discord server, Krystal Team button executes roxploit, Wofly Button executes rock2u ADMIN 2017.

recommendation: open roblox from web site or desktop (optional), and when you will leave of the game close roblox (important).

Get Updates Here: https://discord.gg/qCKx9f8ya7

-------------------------------------------------------------------------------------------------------------------------------------------
GAMES for QuirkyCMD:

https://roblox.com/games/17370532671/
https://roblox.com/games/6069715965/
https://roblox.com/games/14748442840/
https://roblox.com/games/7012102851/
https://roblox.com/games/17744420488/
https://roblox.com/games/3554069044
https://roblox.com/games/9342798896   
https://roblox.com/games/9043532917
https://roblox.com/games/11302512567

(credits: quirkyanimeboy)
-------------------------------------------------------------------------------------------------------------------------------------------
GAMES for Harked Remake:

https://www.roblox.com/games/87854376962069/The-1-000-000-Glass-Bridge
https://www.roblox.com/games/108223641520139/456-000-Squid-Game-Glass-Bridge
https://www.roblox.com/games/18891217864/Cross-Glass-Bridge-to-RICH
https://www.roblox.com/games/120390407164140/1-000-Every-Correct-Glass
https://www.roblox.com/games/18738679670/Pick-Right-Path-to-RICH
https://www.roblox.com/games/18877143786/Cross-Invisible-Path-to-RICH

(credits: trapskap2)